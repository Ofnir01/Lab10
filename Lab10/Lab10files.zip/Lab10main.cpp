#include <iostream>
#include "Bank.h"
using std::cout;

int main() {
	Bank bank;
	bank.simulate();

	return 0;
}